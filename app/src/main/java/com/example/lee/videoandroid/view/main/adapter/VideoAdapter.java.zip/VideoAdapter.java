package com.example.lee.videoandroid.view.main.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.support.annotation.NonNull;
import android.util.Log;
import android.util.LruCache;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.disklrucache.DiskLruCache;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.animation.GlideAnimation;
import com.bumptech.glide.request.target.SimpleTarget;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.example.lee.videoandroid.R;
import com.example.lee.videoandroid.model.UserBean;
import com.example.lee.videoandroid.model.VideoBean;
import com.example.lee.videoandroid.network.Api;
import com.example.lee.videoandroid.util.Utils;
import com.example.lee.videoandroid.util.VideoUtil;
import com.example.lee.videoandroid.view.main.MainActivity;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import wseemann.media.FFmpegMediaMetadataRetriever;

public class VideoAdapter extends BaseQuickAdapter<VideoBean, VideoAdapter.VideoViewHolder> {
    Context mContext;
    FFmpegMediaMetadataRetriever mediaMetadataRetriever;
    LruCache<String, SoftReference<BitmapDrawable>> bitmapLruCache;
    ExecutorService cachedThreadPool = Executors.newCachedThreadPool();
    DiskLruCache diskLruCache;
    public VideoAdapter(Context context, int layoutResId) {
        super(layoutResId, new ArrayList<VideoBean>());
        mContext = context;
        mediaMetadataRetriever = new FFmpegMediaMetadataRetriever();
        final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
        // Use 1/8th of the available memory for this memory cache.
        final int cacheSize = maxMemory / 8;
        Log.e(TAG, "VideoAdapter: cacheSize:" + cacheSize);
        bitmapLruCache = new LruCache<String, SoftReference<BitmapDrawable>>(cacheSize);
        cachedThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    diskLruCache=DiskLruCache.open(new File(Environment.getExternalStorageDirectory()+File.separator+"VideoAndroid"),1,100,100*1024*1024);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public VideoAdapter(Context context, int layoutResId, List<VideoBean> videoBeanList) {
        super(layoutResId, videoBeanList);
        mContext = context;
        mediaMetadataRetriever = new FFmpegMediaMetadataRetriever();
    }

    @Override
    protected void convert(final VideoViewHolder helper, final VideoBean item) {
        helper.titleName.setText(item.getName());
        helper.videoLayout.setDrawingCacheEnabled(true);
        helper.videoLayout.buildDrawingCache();
        SoftReference<BitmapDrawable> drawableSoftReference = bitmapLruCache.get(Api.FILE_HOST + item.getPath());
        if (drawableSoftReference != null) {
            BitmapDrawable drawable = drawableSoftReference.get();
            if (drawable != null) {
                helper.videoLayout.setBackground(drawable);
                return;
            }
        }
        cachedThreadPool.execute(new Runnable() {
            @Override
            public void run() {

                mediaMetadataRetriever.setDataSource(Api.FILE_HOST + item.getPath());
                mediaMetadataRetriever.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_ALBUM);
                mediaMetadataRetriever.extractMetadata(FFmpegMediaMetadataRetriever.METADATA_KEY_ARTIST);
                final SoftReference<Bitmap> bitmap = new SoftReference<>(mediaMetadataRetriever.getFrameAtTime());
                bitmapLruCache.put(Api.FILE_HOST + item.getPath(), new SoftReference<>(new BitmapDrawable(mContext.getResources(), bitmap.get())));
                if (mContext instanceof MainActivity) {
                    ((MainActivity) mContext).runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            helper.videoLayout.setBackground(bitmapLruCache.get(Api.FILE_HOST + item.getPath()).get());
                        }
                    });
                }
            }
        });

    }


    @Override
    public void addData(int position, @NonNull VideoBean data) {
        super.addData(position, data);
    }

    @Override
    public void addData(@NonNull VideoBean data) {
        super.addData(data);
    }

    @Override
    public void addData(@NonNull Collection<? extends VideoBean> newData) {
        super.addData(newData);

    }

    public class VideoViewHolder extends BaseViewHolder {
        private RelativeLayout cardLayout, videoLayout, titleLayout;
        private TextView titleName, videoDuration;

        public VideoViewHolder(View itemView) {
            super(itemView);
            cardLayout = (RelativeLayout) itemView.findViewById(R.id.card_layout);
            videoLayout = (RelativeLayout) itemView.findViewById(R.id.video_layout);
            titleLayout = (RelativeLayout) itemView.findViewById(R.id.title_layout);
            titleName = (TextView) itemView.findViewById(R.id.title_name);
            videoDuration = (TextView) itemView.findViewById(R.id.video_duration);
        }
    }

    public FFmpegMediaMetadataRetriever getMediaMetadataRetriever() {
        return mediaMetadataRetriever;
    }


}
